#!/bin/bash
# =============================================================================
#  consulta_dns_nmap.sh
# -----------------------------------------------------------------------------
#  Herramienta de reconocimiento para Kali Linux.
#
#  FASE 1 - DNS:  obtiene información DNS de un dominio (A, AAAA, MX, NS, TXT,
#                 SOA, transferencia de zona y búsqueda de subdominios).
#                 Con los registros obtenidos clasifica las máquinas que
#                 pueden contener DATOS SENSIBLES (correo, bases de datos,
#                 VPN / acceso remoto, administración, backups, desarrollo...).
#
#  FASE 2 - NMAP: sobre esas máquinas se abre un menú de nmap para:
#                 - determinar el ESTADO de la máquina (up / down)
#                 - ver los PUERTOS y SERVICIOS que ejecuta
#                 - lanzar el NSE correspondiente según servicio y puerto
#
#  Estructura del código (por si quieres modificar algo):
#    1. Variables y colores
#    2. Funciones de apoyo (mensajes, dependencias, validaciones)
#    3. Funciones DNS            -> dns_*
#    4. Clasificación sensibles  -> clasificar_host / detectar_sensibles
#    5. Tabla servicio -> NSE    -> nse_por_servicio
#    6. Funciones NMAP           -> nmap_*
#    7. Menús (while + case)     -> menu_dns / menu_nmap
#    8. Programa principal
#
#  USO:   chmod +x consulta_dns_nmap.sh
#         sudo ./consulta_dns_nmap.sh        (sudo recomendado para nmap -sS / -O)
#
#  AVISO LEGAL: escanea SOLO dominios y máquinas propias o con autorización
#  por escrito. Para practicar: zonetransfer.me (DNS) y scanme.nmap.org (nmap).
# =============================================================================

# -----------------------------------------------------------------------------
# 1. VARIABLES Y COLORES
# -----------------------------------------------------------------------------
VERDE="\e[32m"; ROJO="\e[31m"; AMARILLO="\e[33m"; AZUL="\e[34m"
CIAN="\e[36m"; NEGRITA="\e[1m"; FIN="\e[0m"

DIR_SCRIPT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORDLIST="$DIR_SCRIPT/wordlists/subdominios.txt"
DIR_RESULTADOS="$DIR_SCRIPT/resultados"

dominio=""
dir_salida=""
# Cada objetivo se guarda como:  nombre|ip|categoria
declare -a OBJETIVOS=()

# -----------------------------------------------------------------------------
# 2. FUNCIONES DE APOYO
# -----------------------------------------------------------------------------
separador() { echo -e "${AZUL}------------------------------------------------------------${FIN}"; }
titulo()    { separador; echo -e "${NEGRITA}${CIAN} $1${FIN}"; separador; }
ok()        { echo -e "${VERDE}[+]${FIN} $1"; }
info()      { echo -e "${AZUL}[*]${FIN} $1"; }
aviso()     { echo -e "${AMARILLO}[!]${FIN} $1"; }
error()     { echo -e "${ROJO}[x]${FIN} $1"; }
pausa()     { echo; read -r -p "Pulsa ENTER para continuar..." _; }

# Comprueba que existen las herramientas necesarias
comprobar_dependencias() {
    local faltan=0
    for herramienta in dig nmap; do
        if ! command -v "$herramienta" &>/dev/null; then
            error "Falta '$herramienta'. Instálalo con: sudo apt install ${herramienta/dig/dnsutils}"
            faltan=1
        fi
    done
    [ "$faltan" -eq 1 ] && exit 1
    if [ "$EUID" -ne 0 ]; then
        aviso "No eres root: nmap usará -sT en lugar de -sS y no podrá detectar el SO."
    fi
}

# Valida que el texto introducido tiene formato de dominio (ej: google.es)
validar_dominio() {
    [[ "$1" =~ ^([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$ ]]
}

# Valida una IPv4
validar_ip() {
    [[ "$1" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]
}

# Resuelve un nombre a su primera IPv4
resolver_ip() {
    dig +short "$1" A | grep -E '^[0-9.]+$' | head -n1
}

# Guarda una línea en el informe del dominio
registrar() {
    echo -e "$1" | sed 's/\x1b\[[0-9;]*m//g' >> "$dir_salida/informe_dns.txt"
}

# -----------------------------------------------------------------------------
# 3. FUNCIONES DNS
# -----------------------------------------------------------------------------
# Consulta genérica de un tipo de registro
dns_registro() {
    local tipo="$1" descripcion="$2"
    echo -e "Obteniendo resultado....\n"
    echo -e "${NEGRITA}$descripcion ($tipo) de $dominio:${FIN}"
    local resultado
    resultado=$(dig +short "$dominio" "$tipo")
    if [ -z "$resultado" ]; then
        aviso "No hay registros $tipo."
    else
        echo "$resultado"
    fi
    registrar "\n== $descripcion ($tipo) ==\n${resultado:-(sin registros)}"
}

# Registros TXT + búsqueda de SPF y DMARC
dns_txt() {
    dns_registro TXT "Registros de texto"
    echo
    info "Política SPF:"
    dig +short "$dominio" TXT | grep -i "v=spf1" || aviso "Sin SPF (posible suplantación de correo)."
    info "Política DMARC:"
    dig +short "_dmarc.$dominio" TXT | grep -i "v=dmarc1" || aviso "Sin DMARC."
}

# Intenta una transferencia de zona (AXFR) contra cada servidor NS
dns_transferencia_zona() {
    echo -e "Obteniendo resultado....\n"
    local servidores
    servidores=$(dig +short "$dominio" NS | sed 's/\.$//')
    if [ -z "$servidores" ]; then
        aviso "No se encontraron servidores NS."
        return
    fi
    for ns in $servidores; do
        info "Probando AXFR contra $ns ..."
        local zona
        zona=$(dig axfr "$dominio" @"$ns" +nocomments +nocmd +nostats 2>/dev/null | grep -v -E "^;|^$|Transfer failed|connection")
        if [ -n "$zona" ]; then
            ok "¡Transferencia de zona PERMITIDA en $ns! (fallo de configuración grave)"
            echo "$zona" | tee "$dir_salida/axfr_${ns}.txt"
            registrar "\n== AXFR permitido en $ns ==\n$zona"
            # Añadimos los hosts de la zona como posibles objetivos
            echo "$zona" | awk '$4=="A"{print $1" "$5}' | sed 's/\. / /' | while read -r nombre ip; do
                echo "$nombre|$ip" >> "$dir_salida/.hosts_axfr"
            done
        else
            aviso "$ns no permite la transferencia de zona (correcto)."
        fi
    done
}

# Fuerza bruta de subdominios con el diccionario
dns_subdominios() {
    echo -e "Obteniendo resultado....\n"
    if [ ! -f "$WORDLIST" ]; then
        error "No encuentro el diccionario $WORDLIST"
        return
    fi
    info "Buscando subdominios con $(wc -l < "$WORDLIST") palabras..."
    : > "$dir_salida/subdominios.txt"
    while read -r palabra; do
        [ -z "$palabra" ] && continue
        [[ "$palabra" =~ ^# ]] && continue
        local fqdn="$palabra.$dominio" ip
        ip=$(resolver_ip "$fqdn")
        if [ -n "$ip" ]; then
            printf "  ${VERDE}%-35s${FIN} %s\n" "$fqdn" "$ip"
            echo "$fqdn|$ip" >> "$dir_salida/subdominios.txt"
        fi
    done < "$WORDLIST"
    local total
    total=$(wc -l < "$dir_salida/subdominios.txt")
    ok "Encontrados $total subdominios. Guardados en $dir_salida/subdominios.txt"
    registrar "\n== Subdominios ==\n$(cat "$dir_salida/subdominios.txt")"
}

# Ejecuta todas las consultas seguidas
dns_completo() {
    dns_registro A    "Dirección IPv4";            echo
    dns_registro AAAA "Dirección IPv6";            echo
    dns_registro MX   "Servidores de correo";      echo
    dns_registro NS   "Servidores de nombres";     echo
    dns_registro SOA  "Autoridad de la zona";      echo
    dns_txt;                                       echo
    dns_transferencia_zona;                        echo
    dns_subdominios;                               echo
    detectar_sensibles
}

# -----------------------------------------------------------------------------
# 4. CLASIFICACIÓN DE MÁQUINAS CON DATOS SENSIBLES
# -----------------------------------------------------------------------------
# Devuelve la categoría de un host según su nombre (vacío si no es sensible).
# Solo se analiza la parte del subdominio (db01.empresa.com -> "db01") y se
# busca la palabra clave como "palabra" completa, admitiendo números o guiones
# alrededor (db01, mail-2, srv-backup...), para no dar falsos positivos.
clasificar_host() {
    local nombre="${1,,}"
    nombre="${nombre%.}"
    local etiqueta="${nombre%.$dominio}"
    [ "$etiqueta" = "$nombre" ] && [ "$nombre" = "$dominio" ] && return
    local b='(^|[-_.0-9])'   # borde izquierdo
    local e='([-_.0-9]|$)'   # borde derecho
    if   [[ "$etiqueta" =~ $b(mail|webmail|smtp|imap|pop|pop3|mx|owa|exchange|autodiscover|correo)$e ]]; then echo "Correo electrónico"
    elif [[ "$etiqueta" =~ $b(db|sql|mysql|mssql|mongo|mongodb|oracle|postgres|pgsql|redis|bbdd|database)$e ]]; then echo "Base de datos"
    elif [[ "$etiqueta" =~ $b(vpn|remote|rdp|citrix|ssh|gateway|gw|acceso|ts)$e ]]; then echo "Acceso remoto / VPN"
    elif [[ "$etiqueta" =~ $b(admin|administrator|panel|cpanel|manage|plesk|webmin|gestion)$e ]]; then echo "Administración"
    elif [[ "$etiqueta" =~ $b(backup|backups|bak|nas|files|ftp|sftp|storage|share|copias)$e ]]; then echo "Ficheros / Backups"
    elif [[ "$etiqueta" =~ $b(dev|test|testing|staging|pre|qa|uat|git|gitlab|jenkins|ci|demo)$e ]]; then echo "Desarrollo / Pruebas"
    elif [[ "$etiqueta" =~ $b(intranet|internal|private|corp|ldap|ad|dc|sso|auth|login|secure)$e ]]; then echo "Red interna / Autenticación"
    elif [[ "$etiqueta" =~ $b(api|crm|erp|hr|rrhh|pay|billing|factura|portal)$e ]]; then echo "Aplicación de negocio / API"
    fi
}

# Recorre todos los hosts conocidos y construye la lista de OBJETIVOS
detectar_sensibles() {
    titulo "Máquinas con posibles DATOS SENSIBLES en $dominio"
    OBJETIVOS=()
    local candidatos="$dir_salida/.candidatos"
    : > "$candidatos"

    # a) Servidores de correo (MX) -> siempre sensibles
    dig +short "$dominio" MX | awk '{print $2}' | sed 's/\.$//' | while read -r mx; do
        [ -n "$mx" ] && echo "$mx|$(resolver_ip "$mx")|Correo electrónico (MX)" >> "$candidatos"
    done
    # b) Servidores de nombres (NS) -> contienen toda la zona
    dig +short "$dominio" NS | sed 's/\.$//' | while read -r ns; do
        [ -n "$ns" ] && echo "$ns|$(resolver_ip "$ns")|Servidor DNS (NS)" >> "$candidatos"
    done
    # c) Subdominios y hosts de la transferencia de zona, clasificados por nombre
    for fichero in "$dir_salida/subdominios.txt" "$dir_salida/.hosts_axfr"; do
        [ -f "$fichero" ] || continue
        while IFS='|' read -r nombre ip; do
            local cat
            cat=$(clasificar_host "$nombre")
            [ -n "$cat" ] && echo "$nombre|$ip|$cat" >> "$candidatos"
        done < "$fichero"
    done

    # Quitamos duplicados y entradas sin IP
    while IFS= read -r linea; do
        OBJETIVOS+=("$linea")
    done < <(awk -F'|' '$2!="" && !vistos[$1]++' "$candidatos")

    if [ "${#OBJETIVOS[@]}" -eq 0 ]; then
        aviso "No se han identificado máquinas sensibles."
        aviso "Prueba antes la opción de subdominios (7) o transferencia de zona (6)."
        return
    fi

    printf "${NEGRITA}%-4s %-35s %-16s %s${FIN}\n" "Nº" "HOST" "IP" "TIPO DE DATOS"
    local i=1
    for obj in "${OBJETIVOS[@]}"; do
        IFS='|' read -r nombre ip cat <<< "$obj"
        printf "%-4s %-35s %-16s ${AMARILLO}%s${FIN}\n" "$i" "$nombre" "$ip" "$cat"
        i=$((i+1))
    done
    printf "%s\n" "${OBJETIVOS[@]}" > "$dir_salida/objetivos_sensibles.txt"
    registrar "\n== Máquinas sensibles ==\n$(cat "$dir_salida/objetivos_sensibles.txt")"
    echo
    ok "Lista guardada en $dir_salida/objetivos_sensibles.txt"
}

# -----------------------------------------------------------------------------
# 5. TABLA SERVICIO / PUERTO  ->  SCRIPTS NSE
#    Solo scripts de categorías "safe", "discovery", "default" o "vuln"
#    conocidos (sin fuerza bruta). Añade o cambia los que quieras aquí.
# -----------------------------------------------------------------------------
nse_por_servicio() {
    local servicio="$1" puerto="$2"
    case "$servicio" in
        ftp)                    echo "ftp-anon,ftp-syst,ftp-vsftpd-backdoor" ;;
        ssh)                    echo "ssh2-enum-algos,ssh-hostkey,ssh-auth-methods" ;;
        telnet)                 echo "telnet-encryption,telnet-ntlm-info" ;;
        smtp|smtps|submission)  echo "smtp-commands,smtp-open-relay,smtp-ntlm-info" ;;
        domain)                 echo "dns-nsid,dns-recursion,dns-zone-transfer" ;;
        http|http-proxy|http-alt) echo "http-title,http-headers,http-methods,http-server-header,http-enum,http-robots.txt" ;;
        https|ssl/http|https-alt) echo "ssl-cert,ssl-enum-ciphers,http-title,http-headers,http-security-headers" ;;
        pop3|pop3s)             echo "pop3-capabilities,pop3-ntlm-info" ;;
        imap|imaps)             echo "imap-capabilities,imap-ntlm-info" ;;
        rpcbind)                echo "rpcinfo" ;;
        nfs)                    echo "nfs-showmount,nfs-ls" ;;
        netbios-ssn|microsoft-ds) echo "smb-os-discovery,smb-security-mode,smb2-security-mode,smb-enum-shares,smb-vuln-ms17-010" ;;
        ldap|ldaps)             echo "ldap-rootdse" ;;
        kerberos-sec)           echo "krb5-enum-users" ;;
        ms-sql-s)               echo "ms-sql-info,ms-sql-ntlm-info,ms-sql-empty-password" ;;
        mysql)                  echo "mysql-info,mysql-empty-password" ;;
        postgresql)             echo "banner,ssl-cert" ;;
        oracle-tns)             echo "oracle-tns-version" ;;
        ms-wbt-server)          echo "rdp-enum-encryption,rdp-ntlm-info" ;;
        vnc)                    echo "vnc-info" ;;
        redis)                  echo "redis-info" ;;
        mongodb|mongod)         echo "mongodb-info,mongodb-databases" ;;
        snmp)                   echo "snmp-info,snmp-sysdescr" ;;
        *)
            # Si no reconocemos el servicio, decidimos por el puerto
            case "$puerto" in
                80|8080|8000|8888) echo "http-title,http-headers,http-methods" ;;
                443|8443)          echo "ssl-cert,ssl-enum-ciphers,http-title" ;;
                *)                 echo "banner" ;;
            esac
            ;;
    esac
}

# -----------------------------------------------------------------------------
# 6. FUNCIONES NMAP
# -----------------------------------------------------------------------------
objetivo=""
nombre_objetivo=""

tipo_scan() { [ "$EUID" -eq 0 ] && echo "-sS" || echo "-sT"; }

# Estado de la máquina
nmap_estado() {
    echo -e "Obteniendo resultado....\n"
    info "Comprobando si $objetivo está activo..."
    local salida
    salida=$(nmap -sn "$objetivo" -oN "$dir_salida/nmap_estado_${objetivo}.txt")
    echo "$salida"
    if echo "$salida" | grep -q "Host is up"; then
        ok "ESTADO: la máquina $nombre_objetivo ($objetivo) está ACTIVA (up)."
    else
        aviso "ESTADO: no responde a ping. Puede estar apagada o filtrando ICMP."
        aviso "Las siguientes opciones usan -Pn para escanear igualmente."
    fi
}

# Puertos abiertos y servicio/versión que se ejecuta
nmap_servicios() {
    local modo="$1"   # rapido | completo
    local puertos="--top-ports 1000"
    [ "$modo" = "completo" ] && puertos="-p-"
    echo -e "Obteniendo resultado....\n"
    info "Escaneando puertos y servicios de $objetivo ($modo). Puede tardar..."
    nmap $(tipo_scan) -sV -Pn $puertos --open -T4 "$objetivo" \
        -oN "$dir_salida/nmap_servicios_${objetivo}.txt" \
        -oG "$dir_salida/nmap_servicios_${objetivo}.gnmap"
    echo
    mostrar_tabla_servicios
}

# Lee el fichero grepable (.gnmap) y devuelve líneas "puerto|protocolo|servicio|version"
extraer_puertos() {
    local gnmap="$dir_salida/nmap_servicios_${objetivo}.gnmap"
    [ -f "$gnmap" ] || return 1
    grep "Ports:" "$gnmap" | sed 's/.*Ports: //; s/\tIgnored.*//; s/\t.*//' | tr ',' '\n' | \
    while IFS='/' read -r puerto estado proto _ servicio _ version _; do
        puerto=$(echo "$puerto" | tr -d ' ')
        servicio="${servicio//|//}"    # nmap escribe "ssl|http" -> "ssl/http"
        [ "$estado" = "open" ] && echo "$puerto|$proto|$servicio|$version"
    done
}

mostrar_tabla_servicios() {
    local datos
    datos=$(extraer_puertos)
    if [ -z "$datos" ]; then
        aviso "No se encontraron puertos abiertos (o aún no has hecho el escaneo de servicios)."
        return 1
    fi
    titulo "Servicios en $nombre_objetivo ($objetivo) y NSE recomendado"
    printf "${NEGRITA}%-8s %-6s %-16s %-28s %s${FIN}\n" "PUERTO" "PROTO" "SERVICIO" "VERSIÓN" "NSE"
    while IFS='|' read -r puerto proto servicio version; do
        printf "%-8s %-6s %-16s %-28s ${CIAN}%s${FIN}\n" "$puerto" "$proto" "$servicio" \
            "${version:0:27}" "$(nse_por_servicio "$servicio" "$puerto")"
    done <<< "$datos"
}

# Lanza, puerto a puerto, el NSE que corresponde a cada servicio
nmap_nse() {
    local datos
    datos=$(extraer_puertos)
    if [ -z "$datos" ]; then
        aviso "Primero necesito saber los servicios. Lanzo el escaneo rápido..."
        nmap_servicios rapido
        datos=$(extraer_puertos)
        [ -z "$datos" ] && return
    fi
    local informe="$dir_salida/nmap_nse_${objetivo}.txt"
    : > "$informe"
    while IFS='|' read -r puerto proto servicio version; do
        local scripts args=""
        scripts=$(nse_por_servicio "$servicio" "$puerto")
        # Algunos scripts necesitan argumentos extra
        if [[ "$scripts" == *"--script-args"* ]]; then
            args="--script-args ${scripts#*--script-args }"
            scripts="${scripts%% --script-args*}"
        fi
        [[ "$scripts" == *dns-zone-transfer* ]] && args="--script-args dns-zone-transfer.domain=$dominio"
        [[ "$scripts" == *krb5-enum-users* ]]  && args="--script-args krb5-enum-users.realm=${dominio^^}"
        local flag_proto=""
        [ "$proto" = "udp" ] && flag_proto="-sU"
        separador
        info "Puerto ${NEGRITA}$puerto/$proto${FIN} ($servicio) -> NSE: ${CIAN}$scripts${FIN}"
        # shellcheck disable=SC2086
        nmap -Pn $flag_proto -sV -p "$puerto" --script "$scripts" $args "$objetivo" | tee -a "$informe"
    done <<< "$datos"
    echo
    ok "Resultados NSE guardados en $informe"
}

# Detección de sistema operativo (requiere root)
nmap_so() {
    echo -e "Obteniendo resultado....\n"
    if [ "$EUID" -ne 0 ]; then
        error "La detección de SO necesita root. Ejecuta el script con sudo."
        return
    fi
    nmap -O -Pn --osscan-guess "$objetivo" -oN "$dir_salida/nmap_so_${objetivo}.txt"
}

# Escaneo de vulnerabilidades conocidas con la categoría "vuln"
nmap_vuln() {
    echo -e "Obteniendo resultado....\n"
    aviso "La categoría 'vuln' es más intrusiva. Úsala solo con autorización."
    read -r -p "¿Continuar? (s/n): " r
    [[ "$r" =~ ^[sS]$ ]] || return
    nmap -Pn -sV --script vuln "$objetivo" -oN "$dir_salida/nmap_vuln_${objetivo}.txt"
}

# Seleccionar objetivo de la lista de máquinas sensibles o escribir uno a mano
elegir_objetivo() {
    if [ "${#OBJETIVOS[@]}" -eq 0 ]; then
        aviso "No hay máquinas sensibles detectadas todavía."
    else
        local i=1
        for obj in "${OBJETIVOS[@]}"; do
            IFS='|' read -r nombre ip cat <<< "$obj"
            printf "%-4s %-35s %-16s %s\n" "$i)" "$nombre" "$ip" "$cat"
            i=$((i+1))
        done
    fi
    echo "M) Escribir IP o host manualmente"
    read -r -p "¿Qué máquina quieres evaluar? " sel
    if [[ "$sel" =~ ^[0-9]+$ ]] && [ "$sel" -ge 1 ] && [ "$sel" -le "${#OBJETIVOS[@]}" ]; then
        IFS='|' read -r nombre_objetivo objetivo _ <<< "${OBJETIVOS[$((sel-1))]}"
    elif [[ "$sel" =~ ^[mM]$ ]]; then
        read -r -p "IP o nombre de host: " manual
        if validar_ip "$manual"; then
            objetivo="$manual"; nombre_objetivo="$manual"
        else
            objetivo=$(resolver_ip "$manual"); nombre_objetivo="$manual"
        fi
    fi
    if [ -z "$objetivo" ]; then
        error "Objetivo no válido."
        return 1
    fi
    ok "Objetivo seleccionado: $nombre_objetivo ($objetivo)"
}

# -----------------------------------------------------------------------------
# 7. MENÚS
# -----------------------------------------------------------------------------
menu_nmap() {
    objetivo=""; nombre_objetivo=""
    titulo "NMAP - Selección de objetivo"
    elegir_objetivo || { pausa; return; }
    while true
    do
        titulo "NMAP sobre $nombre_objetivo ($objetivo)"
        echo "1. Estado de la máquina (up / down)"
        echo "2. Puertos y servicios (1000 puertos más comunes)"
        echo "3. Puertos y servicios (los 65535 puertos)"
        echo "4. Lanzar NSE según servicio y puerto detectados"
        echo "5. Ver tabla servicio / puerto / NSE recomendado"
        echo "6. Detección de sistema operativo (root)"
        echo "7. Escaneo de vulnerabilidades (NSE vuln)"
        echo "8. Evaluación completa (1 + 2 + 4)"
        echo "9. Cambiar de objetivo"
        echo "--------------"
        echo "0. Volver al menú DNS"
        read -r -p "¿Qué opción eliges? " opcion_nmap

        case $opcion_nmap in
            1) nmap_estado ;;
            2) nmap_servicios rapido ;;
            3) nmap_servicios completo ;;
            4) nmap_nse ;;
            5) mostrar_tabla_servicios ;;
            6) nmap_so ;;
            7) nmap_vuln ;;
            8) nmap_estado; nmap_servicios rapido; nmap_nse ;;
            9) objetivo=""; elegir_objetivo ;;
            0) return ;;
            *) error "Opción no válida." ;;
        esac
        pausa
    done
}

menu_dns() {
    while true
    do
        titulo "Dominio: $dominio"
        echo "Opciones disponibles en la herramienta"
        echo "1. Consulta de IP (A)"
        echo "2. Consulta de IPv6 (AAAA)"
        echo "3. Consulta de correo electrónico (MX)"
        echo "4. Consulta de nombre de servidor (NS)"
        echo "5. Consulta de registros TXT (SPF / DMARC)"
        echo "6. Intentar transferencia de zona (AXFR)"
        echo "7. Buscar subdominios (diccionario)"
        echo "8. Consulta de autoridad (SOA)"
        echo "9. CONSULTA DNS COMPLETA (todo lo anterior + máquinas sensibles)"
        echo "--------------"
        echo "10. Mostrar máquinas con datos sensibles"
        echo "11. Ir al menú NMAP (evaluar máquinas sensibles)"
        echo "12. Cambiar de dominio"
        echo "--------------"
        echo "0. Salir de la herramienta"
        read -r -p "¿Qué opción eliges? " opcion

        case $opcion in
            1) dns_registro A "La IP es" ;;
            2) dns_registro AAAA "La IPv6 es" ;;
            3) dns_registro MX "El servidor de correo es" ;;
            4) dns_registro NS "El servidor de nombres es" ;;
            5) dns_txt ;;
            6) dns_transferencia_zona ;;
            7) dns_subdominios ;;
            8) dns_registro SOA "La autoridad de la zona es" ;;
            9) dns_completo ;;
            10) detectar_sensibles ;;
            11) [ "${#OBJETIVOS[@]}" -eq 0 ] && detectar_sensibles; menu_nmap; continue ;;
            12) return ;;
            0)
                echo "Saliendo de la herramienta...."
                echo "Resultados guardados en: $dir_salida"
                exit 0
                ;;
            *) error "Opción no válida, elige un número del menú." ;;
        esac
        pausa
    done
}

# -----------------------------------------------------------------------------
# 8. PROGRAMA PRINCIPAL
# -----------------------------------------------------------------------------
clear
comprobar_dependencias
while true
do
    echo "----------- o -----------"
    echo -e "${NEGRITA}Bienvenid@ a la herramienta de consulta de dominio y evaluación con nmap.${FIN}"
    echo " Esto es un ejemplo de lo que debes escribir ---> google.es"
    aviso "Usa solo dominios propios o con autorización (prueba: zonetransfer.me)"
    read -r -p "Escribe el dominio: " dominio
    dominio="${dominio,,}"

    if ! validar_dominio "$dominio"; then
        error "'$dominio' no es un dominio válido."
        continue
    fi
    if [ -z "$(dig +short "$dominio" SOA)" ] && [ -z "$(dig +short "$dominio" A)" ]; then
        error "El dominio $dominio no responde en DNS."
        continue
    fi

    dir_salida="$DIR_RESULTADOS/${dominio}_$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$dir_salida"
    OBJETIVOS=()
    registrar "Informe DNS de $dominio - $(date)"
    ok "Los resultados se guardarán en $dir_salida"
    menu_dns
done
