# dns-nmap-recon

Herramienta en **Bash para Kali Linux** que:

1. **Obtiene información DNS** de un dominio (A, AAAA, MX, NS, TXT/SPF/DMARC, SOA, transferencia de zona AXFR y búsqueda de subdominios por diccionario).
2. **Identifica las máquinas que pueden contener datos sensibles** a partir de esos registros (correo, bases de datos, VPN/acceso remoto, administración, backups, desarrollo, autenticación…).
3. Abre un **menú de nmap** sobre esas máquinas para determinar:
   - el **estado** de la máquina (up / down),
   - los **puertos y servicios** que ejecuta (con versión),
   - y lanzar el **script NSE correspondiente** según el servicio y el puerto detectados.

> ⚠️ **Aviso legal:** usa la herramienta solo contra dominios y equipos propios o con autorización por escrito.
> Para practicar: `zonetransfer.me` (permite AXFR a propósito) y `scanme.nmap.org` (Nmap permite escanearlo).

---

## Requisitos

```bash
sudo apt update
sudo apt install dnsutils nmap git
```

(En Kali ya vienen instalados `dig` y `nmap`.)

## Instalación y uso

```bash
git clone https://github.com/<TU_USUARIO>/dns-nmap-recon.git
cd dns-nmap-recon
chmod +x consulta_dns_nmap.sh
sudo ./consulta_dns_nmap.sh
```

Se recomienda `sudo` para que nmap use SYN scan (`-sS`) y pueda detectar el sistema operativo. Sin root funciona igual, pero con `-sT`.

## Flujo de trabajo

```
Dominio ──► Menú DNS ──► (9) Consulta completa ──► Máquinas sensibles ──► (11) Menú NMAP
                                                                            │
                          ┌─────────────────────────────────────────────────┘
                          ▼
            1 Estado  ►  2 Puertos/servicios  ►  4 NSE según servicio  ►  resultados/
```

### Menú DNS

| Opción | Acción | Comando usado |
|---|---|---|
| 1 | IP (A) | `dig +short dominio A` |
| 2 | IPv6 (AAAA) | `dig +short dominio AAAA` |
| 3 | Correo (MX) | `dig +short dominio MX` |
| 4 | Servidores de nombres (NS) | `dig +short dominio NS` |
| 5 | TXT + SPF + DMARC | `dig +short dominio TXT`, `_dmarc.dominio` |
| 6 | Transferencia de zona | `dig axfr dominio @ns` |
| 7 | Subdominios | `dig +short palabra.dominio` con `wordlists/subdominios.txt` |
| 8 | Autoridad (SOA) | `dig +short dominio SOA` |
| 9 | **Consulta completa** + detección de máquinas sensibles | todas las anteriores |
| 10 | Mostrar máquinas sensibles | |
| 11 | **Ir al menú NMAP** | |
| 12 | Cambiar de dominio | |
| 0 | Salir | |

### Cómo se detectan las máquinas sensibles

- Todos los **MX** (correo) y **NS** (contienen la zona DNS) se consideran sensibles.
- Los subdominios encontrados (diccionario o AXFR) se clasifican por palabras clave en el nombre:

| Categoría | Palabras clave (ejemplos) |
|---|---|
| Correo electrónico | mail, webmail, smtp, imap, owa, exchange |
| Base de datos | db, sql, mysql, mongo, oracle, postgres, redis |
| Acceso remoto / VPN | vpn, remote, rdp, citrix, ssh, gateway |
| Administración | admin, panel, cpanel, webmin, plesk |
| Ficheros / Backups | backup, bak, nas, ftp, files, storage |
| Desarrollo / Pruebas | dev, test, staging, qa, git, jenkins |
| Red interna / Autenticación | intranet, ldap, ad, dc, sso, auth, login |
| Aplicación de negocio / API | api, crm, erp, hr, billing, portal |

### Menú NMAP

| Opción | Acción | Comando nmap |
|---|---|---|
| 1 | Estado de la máquina | `nmap -sn IP` |
| 2 | Puertos y servicios (top 1000) | `nmap -sS -sV -Pn --top-ports 1000 --open IP` |
| 3 | Puertos y servicios (todos) | `nmap -sS -sV -Pn -p- --open IP` |
| 4 | **NSE según servicio y puerto** | `nmap -Pn -sV -p PUERTO --script <NSE> IP` (uno por puerto) |
| 5 | Tabla servicio / puerto / NSE | |
| 6 | Sistema operativo (root) | `nmap -O --osscan-guess IP` |
| 7 | Vulnerabilidades | `nmap -sV --script vuln IP` (pide confirmación) |
| 8 | Evaluación completa | 1 + 2 + 4 |
| 9 | Cambiar de objetivo | |

### Tabla servicio → NSE

| Servicio (puerto típico) | Scripts NSE |
|---|---|
| ftp (21) | ftp-anon, ftp-syst, ftp-vsftpd-backdoor |
| ssh (22) | ssh2-enum-algos, ssh-hostkey, ssh-auth-methods |
| telnet (23) | telnet-encryption, telnet-ntlm-info |
| smtp (25/465/587) | smtp-commands, smtp-open-relay, smtp-ntlm-info |
| domain (53) | dns-nsid, dns-recursion, dns-zone-transfer |
| http (80/8080) | http-title, http-headers, http-methods, http-server-header, http-enum, http-robots.txt |
| https (443/8443) | ssl-cert, ssl-enum-ciphers, http-title, http-headers, http-security-headers |
| pop3 / imap (110/143/993/995) | pop3-capabilities, imap-capabilities, *-ntlm-info |
| rpcbind (111) / nfs (2049) | rpcinfo / nfs-showmount, nfs-ls |
| smb (139/445) | smb-os-discovery, smb-security-mode, smb2-security-mode, smb-enum-shares, smb-vuln-ms17-010 |
| ldap (389/636) | ldap-rootdse |
| kerberos (88) | krb5-enum-users |
| mssql (1433) | ms-sql-info, ms-sql-ntlm-info, ms-sql-empty-password |
| mysql (3306) | mysql-info, mysql-empty-password |
| rdp (3389) | rdp-enum-encryption, rdp-ntlm-info |
| vnc (5900) | vnc-info |
| redis (6379) | redis-info |
| mongodb (27017) | mongodb-info, mongodb-databases |
| otro | banner |

La tabla está en la función `nse_por_servicio` del script: se pueden añadir o cambiar scripts fácilmente.

## Resultados

Cada ejecución guarda los resultados en `resultados/<dominio>_<fecha>/`:

```
informe_dns.txt              # resumen de todas las consultas DNS
subdominios.txt              # subdominios encontrados (host|ip)
axfr_<ns>.txt                # zona completa si el AXFR está permitido
objetivos_sensibles.txt      # máquinas sensibles (host|ip|categoría)
nmap_estado_<ip>.txt
nmap_servicios_<ip>.txt / .gnmap
nmap_nse_<ip>.txt
nmap_so_<ip>.txt / nmap_vuln_<ip>.txt
```

La carpeta `resultados/` está en `.gitignore` para no subir escaneos al repositorio.

## Estructura del repositorio

```
dns-nmap-recon/
├── consulta_dns_nmap.sh      # script principal
├── wordlists/
│   └── subdominios.txt       # diccionario de subdominios
├── capturas/                 # capturas de la ejecución (para la entrega)
├── .gitignore
└── README.md
```

## Ejemplo de prueba

```bash
sudo ./consulta_dns_nmap.sh
Escribe el dominio: zonetransfer.me
¿Qué opción eliges? 9          # consulta DNS completa + máquinas sensibles
¿Qué opción eliges? 11         # menú nmap
¿Qué máquina quieres evaluar? M
IP o nombre de host: scanme.nmap.org
¿Qué opción eliges? 8          # estado + servicios + NSE
```
